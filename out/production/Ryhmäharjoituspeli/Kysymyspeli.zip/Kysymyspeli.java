import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;




public class Kysymyspeli {

    List<String> kysymykset;
    List<String> oikeatVastaukset;

    public Kysymyspeli() {  //konstruktori
    }

    public void kysyKysymys() {
        List<String> kysymykset = new ArrayList<>();
        kysymykset.add("Mikä viikonpäivä aloittaa viikon?(Maanantai/Tiistai/Keskiviikko)");
        kysymykset.add("Kuka kirjoitti romaanin Vuonna 1984?(Huxley/Orwell/Shakespeare)");
        kysymykset.add("Mikä on Espanjan pääkaupunki? (Barcelona/Lissabon/Madrid)");
        kysymykset.add("Mikä on Suomen pääkaupunki? (Helsinki/Turku/Rovaniemi");
        kysymykset.add ("Kuinka paljon on 2+2? (4/5/42)");

        List<String> oikeatVastaukset = new ArrayList<>();
        oikeatVastaukset.add("Maanantai");
        oikeatVastaukset.add("Orwell");
        oikeatVastaukset.add("Madrid");
        oikeatVastaukset.add("Helsinki");
        oikeatVastaukset.add("4");


        int pistelaskuri = 0;
        int indeksi = 0;


        for (int kysIndeksi = 0; kysIndeksi< kysymykset.size(); kysIndeksi++) {

            System.out.println(kysymykset.get(kysIndeksi));
            Scanner lukija = new Scanner(System.in);
            String vastaus = lukija.nextLine();


            if (vastaus.equals(oikeatVastaukset.get(indeksi))) {
                pistelaskuri++;
                System.out.println("Oikein! Pisteitä kasassa: " + pistelaskuri);
            } else {
                System.out.println("Väärin!Pisteitä kasassa: " + pistelaskuri);
            }

            indeksi ++;
        }


    }
}

