import java.util.ArrayList;
import java.util.List;

public class Peli {
    public static void main(String[] args) {

        Kysymyspeli uusi = new Kysymyspeli();
        uusi.kysyKysymys();



    }
}
